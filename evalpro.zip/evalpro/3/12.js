

document.querySelector("#form").addEventListener("submit", submitFun);


function submitFun(elme) {
    elme.preventDefault();
    username = document.querySelector("#name").value;
    password =  document.querySelector("#password").value;

    if (username == "Prathamesh" && password == "14") {
       
        window.location.href = "index.html";
    } else if (username == "Rutuja" && password == "16") {
       
        window.location.href = "index.html";
    } else if (username == "Vaishnavi" && password == "8") {
       
        window.location.href = "index.html";
    } else if (username == "Uday" && password == "14") {
       
        window.location.href = "index.html";
    } else {
        alert("Invalid username or password");
        document.querySelector("#form").reset();
    }

}



